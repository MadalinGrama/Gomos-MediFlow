<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    public function __construct()
    {
        // Aplică middleware-ul 'admin' pentru toate metodele din acest controler
        $this->middleware('admin');
    }

    public function index(){   
        // dd('Metoda index a fost apelată.');      

        return view('admin.dashboard');
    }
}
